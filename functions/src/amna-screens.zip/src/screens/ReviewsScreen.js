import React from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { colors, fonts } from '../../theme';
import { reviewsList } from '../data/pros';

const DIST = [
  { star: 5, pct: 88 },
  { star: 4, pct: 9 },
  { star: 3, pct: 2 },
  { star: 2, pct: 1 },
  { star: 1, pct: 0 },
];

export default function ReviewsScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <View style={styles.head}>
        <TouchableOpacity style={styles.back} onPress={() => navigation.goBack()}>
          <Feather name="chevron-left" size={20} color={colors.ink} />
        </TouchableOpacity>
        <Text style={styles.title}>Avis clients</Text>
      </View>

      <View style={styles.summary}>
        <View style={{ alignItems: 'center' }}>
          <Text style={styles.big}>4.9</Text>
          <Text style={styles.bigStars}>★★★★★</Text>
          <Text style={styles.cnt}>128 avis</Text>
        </View>
        <View style={{ flex: 1, gap: 4 }}>
          {DIST.map((d) => (
            <View key={d.star} style={styles.bar}>
              <Text style={styles.barNum}>{d.star}</Text>
              <View style={styles.track}><View style={[styles.fill, { width: `${d.pct}%` }]} /></View>
            </View>
          ))}
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 4 }} showsVerticalScrollIndicator={false}>
        {reviewsList.map((r, i) => (
          <View key={i} style={styles.review}>
            <View style={styles.reviewHead}>
              <Image source={{ uri: `https://i.pravatar.cc/80?img=${r.img}` }} style={styles.reviewAv} />
              <View>
                <Text style={styles.reviewNm}>{r.n}</Text>
                <Text style={styles.reviewD}>{r.d}</Text>
              </View>
              <Text style={styles.reviewStars}>{'★'.repeat(r.s)}{'☆'.repeat(5 - r.s)}</Text>
            </View>
            <Text style={styles.reviewTxt}>{r.t}</Text>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  head: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingTop: 6, paddingBottom: 8 },
  back: { width: 40, height: 40, borderRadius: 13, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: fonts.display, fontSize: 20, color: colors.ink },
  summary: { flexDirection: 'row', gap: 16, alignItems: 'center', paddingHorizontal: 18, paddingVertical: 14 },
  big: { fontFamily: fonts.display, fontSize: 46, color: colors.ink },
  bigStars: { color: colors.gold, fontSize: 15 },
  cnt: { fontFamily: fonts.body, fontSize: 12, color: colors.muted, marginTop: 4 },
  bar: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  barNum: { fontFamily: fonts.bodySemi, fontSize: 11, color: colors.muted, width: 10 },
  track: { flex: 1, height: 6, borderRadius: 99, backgroundColor: colors.line, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: 99, backgroundColor: colors.gold },
  review: { backgroundColor: '#fff', borderWidth: 1, borderColor: colors.line, borderRadius: 16, padding: 13, marginBottom: 9 },
  reviewHead: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  reviewAv: { width: 34, height: 34, borderRadius: 10, backgroundColor: '#cdd9d7' },
  reviewNm: { fontFamily: fonts.bodyBold, fontSize: 13, color: colors.ink },
  reviewD: { fontFamily: fonts.bodyMed, fontSize: 10.5, color: colors.muted2 },
  reviewStars: { marginLeft: 'auto', color: colors.gold, fontSize: 12 },
  reviewTxt: { fontFamily: fonts.body, fontSize: 13, lineHeight: 20, color: colors.inkSoft, marginTop: 8 },
});
