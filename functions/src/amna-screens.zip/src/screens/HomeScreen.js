import React from 'react';
import { View, Text, TextInput, ScrollView, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { colors, fonts, radius, shadow } from '../../theme';
import { categories, pros } from '../data/pros';

export default function HomeScreen({ navigation }) {
  const livePros = pros.filter((p) => p.live);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        {/* Header */}
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={styles.hi}>Bonjour 👋</Text>
            <View style={styles.cityRow}>
              <Feather name="map-pin" size={15} color={colors.coral} />
              <Text style={styles.city}>Dakar, Sacré-Cœur</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.bell} activeOpacity={0.8} onPress={() => navigation.navigate('Notifications')}>
            <Feather name="bell" size={20} color={colors.ink} />
            <View style={styles.bellDot} />
          </TouchableOpacity>
          <TouchableOpacity activeOpacity={0.8} onPress={() => navigation.navigate('Profil')}>
            <Image source={{ uri: 'https://i.pravatar.cc/120?img=5' }} style={styles.meAv} />
          </TouchableOpacity>
        </View>

        {/* Search */}
        <View style={styles.search}>
          <Feather name="search" size={19} color={colors.muted} />
          <TextInput
            placeholder="De quoi tu as besoin aujourd'hui ?"
            placeholderTextColor={colors.muted2}
            style={styles.searchInput}
          />
        </View>

        {/* Services */}
        <View style={styles.secRow}>
          <Text style={styles.secTitle}>Services</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Carte')}>
            <Text style={styles.link}>Tout voir</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.cats}>
          {categories.map((c) => (
            <TouchableOpacity
              key={c.key}
              style={styles.cat}
              activeOpacity={0.8}
              onPress={() => navigation.navigate('Carte', { category: c.key })}
            >
              <View style={[styles.catIc, { backgroundColor: c.tint }]}>
                <Text style={{ fontSize: 23 }}>{c.emoji}</Text>
              </View>
              <Text style={styles.catLb}>{c.key}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* En live */}
        <View style={[styles.secRow, { marginTop: 22 }]}>
          <Text style={styles.secTitle}>En live près de toi</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Carte')}>
            <Text style={styles.link}>Carte</Text>
          </TouchableOpacity>
        </View>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 18, gap: 12 }}
        >
          {livePros.map((p) => (
            <TouchableOpacity
              key={p.id}
              style={styles.lcard}
              activeOpacity={0.9}
              onPress={() => navigation.navigate('Profile', { id: p.id })}
            >
              <View style={styles.lph}>
                <Image source={{ uri: p.cover }} style={styles.lphImg} />
                <View style={styles.liveb}>
                  <View style={styles.liveDot} />
                  <Text style={styles.livebTxt}>LIVE</Text>
                </View>
                {p.prem && (
                  <View style={styles.premb}>
                    <Text style={styles.prembTxt}>PRO+</Text>
                  </View>
                )}
              </View>
              <View style={{ padding: 11 }}>
                <Text style={styles.lname}>{p.name}</Text>
                <Text style={styles.ltrade}>{p.trade.split(' · ')[0]}</Text>
                <View style={styles.lmeta}>
                  <Text style={styles.lstar}>★ {p.rate}</Text>
                  <Text style={styles.lkm}>{p.km.toString().replace('.', ',')} km</Text>
                  <Text style={styles.lprice}>{p.price}</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Devenir pro */}
        <TouchableOpacity style={styles.banner} activeOpacity={0.9} onPress={() => navigation.navigate('Pro')}>
          <View style={{ flex: 1 }}>
            <Text style={styles.bannerTitle}>Tu offres un service ?</Text>
            <Text style={styles.bannerSub}>Passe en live et reçois des clients autour de toi.</Text>
          </View>
          <View style={styles.bannerBtn}>
            <Text style={styles.bannerBtnTxt}>Devenir pro</Text>
          </View>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', gap: 11, paddingHorizontal: 18, paddingTop: 4, marginBottom: 16 },
  hi: { fontFamily: fonts.bodyMed, fontSize: 13, color: colors.muted },
  cityRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  city: { fontFamily: fonts.display, fontSize: 20, color: colors.ink, letterSpacing: -0.3 },
  bell: { width: 44, height: 44, borderRadius: 14, backgroundColor: colors.card, alignItems: 'center', justifyContent: 'center', ...shadow(8) },
  bellDot: { position: 'absolute', top: 11, right: 12, width: 8, height: 8, borderRadius: 4, backgroundColor: colors.coral, borderWidth: 2, borderColor: '#fff' },
  meAv: { width: 44, height: 44, borderRadius: 14, borderWidth: 2, borderColor: '#fff', ...shadow(8) },

  search: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: colors.card, borderRadius: 17, paddingHorizontal: 15, paddingVertical: 13, marginHorizontal: 18, ...shadow(8) },
  searchInput: { flex: 1, fontFamily: fonts.body, fontSize: 14, color: colors.ink, padding: 0 },

  secRow: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', paddingHorizontal: 18, marginTop: 18, marginBottom: 13 },
  secTitle: { fontFamily: fonts.displaySemi, fontSize: 16, color: colors.ink },
  link: { fontFamily: fonts.bodySemi, fontSize: 12.5, color: colors.coral },

  cats: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 18, gap: 11 },
  cat: { width: '31%', backgroundColor: colors.card, borderWidth: 1, borderColor: colors.line, borderRadius: 18, paddingVertical: 14, alignItems: 'center', gap: 8 },
  catIc: { width: 46, height: 46, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  catLb: { fontFamily: fonts.bodySemi, fontSize: 11.5, color: colors.inkSoft },

  lcard: { width: 162, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.line, borderRadius: 18, overflow: 'hidden', ...shadow(8) },
  lph: { height: 90 },
  lphImg: { width: '100%', height: '100%' },
  liveb: { position: 'absolute', top: 8, left: 8, flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: colors.coral, paddingHorizontal: 7, paddingVertical: 3, borderRadius: 8 },
  liveDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: '#fff' },
  livebTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 9.5 },
  premb: { position: 'absolute', top: 8, right: 8, backgroundColor: colors.gold, paddingHorizontal: 6, paddingVertical: 3, borderRadius: 7 },
  prembTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 8.5 },
  lname: { fontFamily: fonts.bodyBold, fontSize: 13.5, color: colors.ink },
  ltrade: { fontFamily: fonts.body, fontSize: 11, color: colors.muted, marginTop: 1 },
  lmeta: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8 },
  lstar: { fontFamily: fonts.bodyBold, fontSize: 11.5, color: colors.gold },
  lkm: { fontFamily: fonts.bodySemi, fontSize: 11.5, color: colors.muted },
  lprice: { marginLeft: 'auto', fontFamily: fonts.mono, fontSize: 11.5, color: colors.ink },

  banner: { flexDirection: 'row', alignItems: 'center', gap: 14, marginHorizontal: 18, marginTop: 20, backgroundColor: colors.inkSoft, borderRadius: 20, padding: 18 },
  bannerTitle: { fontFamily: fonts.displaySemi, fontSize: 15, color: '#fff' },
  bannerSub: { fontFamily: fonts.body, fontSize: 12, color: '#a8c2c3', marginTop: 4, lineHeight: 16 },
  bannerBtn: { backgroundColor: colors.coral, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 11 },
  bannerBtnTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 12.5 },
});
