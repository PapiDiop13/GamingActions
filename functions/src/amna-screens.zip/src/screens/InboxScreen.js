import React from 'react';
import { View, Text, Image, TextInput, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { colors, fonts, shadow } from '../../theme';
import { conversations, getPro } from '../data/pros';

export default function InboxScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <View style={styles.head}>
        <Text style={styles.title}>Messages</Text>
        <View style={styles.search}>
          <Feather name="search" size={17} color={colors.muted} />
          <TextInput placeholder="Rechercher une conversation" placeholderTextColor={colors.muted2} style={styles.searchInput} />
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {conversations.map((c) => {
          const p = getPro(c.proId);
          return (
            <TouchableOpacity key={c.proId} style={styles.row} activeOpacity={0.8} onPress={() => navigation.navigate('Chat', { id: c.proId })}>
              <View>
                <Image source={{ uri: p.avatar }} style={styles.av} />
                {p.live && <View style={styles.lv} />}
              </View>
              <View style={{ flex: 1 }}>
                <View style={styles.top}>
                  <Text style={styles.nm}>{p.name}</Text>
                  <Text style={styles.time}>{c.time}</Text>
                </View>
                <Text style={[styles.preview, c.unread > 0 && styles.previewUnread]} numberOfLines={1}>{c.last}</Text>
              </View>
              {c.unread > 0 && (
                <View style={styles.badge}><Text style={styles.badgeTxt}>{c.unread}</Text></View>
              )}
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  head: { paddingHorizontal: 20, paddingTop: 4, paddingBottom: 14 },
  title: { fontFamily: fonts.display, fontSize: 26, color: colors.ink },
  search: { flexDirection: 'row', alignItems: 'center', gap: 9, backgroundColor: colors.card, borderRadius: 14, paddingHorizontal: 13, paddingVertical: 11, marginTop: 12, ...shadow(8) },
  searchInput: { flex: 1, fontFamily: fonts.body, fontSize: 13.5, color: colors.ink, padding: 0 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20, paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: '#EEF2F1' },
  av: { width: 52, height: 52, borderRadius: 15, backgroundColor: '#cdd9d7' },
  lv: { position: 'absolute', right: -2, bottom: -2, width: 14, height: 14, borderRadius: 7, backgroundColor: colors.coral, borderWidth: 2.5, borderColor: '#fff' },
  top: { flexDirection: 'row', alignItems: 'center' },
  nm: { flex: 1, fontFamily: fonts.bodyBold, fontSize: 14.5, color: colors.ink },
  time: { fontFamily: fonts.bodySemi, fontSize: 11, color: colors.muted2 },
  preview: { fontFamily: fonts.body, fontSize: 12.5, color: colors.muted, marginTop: 3 },
  previewUnread: { color: colors.ink, fontFamily: fonts.bodySemi },
  badge: { width: 20, height: 20, borderRadius: 10, backgroundColor: colors.coral, alignItems: 'center', justifyContent: 'center' },
  badgeTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 11 },
});
