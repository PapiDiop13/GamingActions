import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { colors, fonts, shadow } from '../../theme';

export default function AuthScreen({ navigation }) {
  const [step, setStep] = useState(1);
  const [phone, setPhone] = useState('');

  const next = () => (step === 1 ? setStep(2) : navigation.replace('Tabs'));

  return (
    <SafeAreaView style={styles.root} edges={['top', 'bottom']}>
      <View style={styles.top}>
        <TouchableOpacity style={styles.back} onPress={() => (step === 2 ? setStep(1) : navigation.goBack())}>
          <Feather name="chevron-left" size={20} color={colors.ink} />
        </TouchableOpacity>
      </View>

      <View style={styles.mid}>
        {step === 1 ? (
          <>
            <Text style={styles.h2}>Ton numéro</Text>
            <Text style={styles.sub}>On t'envoie un code par SMS. Rapide et sans mot de passe.</Text>
            <View style={styles.phoneRow}>
              <View style={styles.cc}><Text style={styles.ccTxt}>🇸🇳 +221</Text></View>
              <TextInput
                style={styles.phoneInput}
                placeholder="77 123 45 67"
                placeholderTextColor={colors.muted2}
                keyboardType="number-pad"
                value={phone}
                onChangeText={setPhone}
              />
            </View>
          </>
        ) : (
          <>
            <Text style={styles.h2}>Entre le code</Text>
            <Text style={styles.sub}>Code envoyé au +221 {phone || '77 123 45 67'}</Text>
            <View style={styles.otp}>
              {['4', '8', '_', '_'].map((d, k) => (
                <View key={k} style={[styles.otpBox, k < 2 && styles.otpFill]}>
                  <Text style={[styles.otpTxt, k < 2 && { color: colors.coral }]}>{d}</Text>
                </View>
              ))}
            </View>
            <Text style={styles.resend}>Pas reçu ? <Text style={{ color: colors.coral, fontFamily: fonts.bodyBold }}>Renvoyer (0:23)</Text></Text>
          </>
        )}
      </View>

      <View style={styles.foot}>
        <TouchableOpacity style={styles.btn} onPress={next} activeOpacity={0.9}>
          <Text style={styles.btnTxt}>{step === 1 ? 'Continuer' : 'Vérifier'}</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg, paddingHorizontal: 24 },
  top: { paddingTop: 8 },
  back: { width: 40, height: 40, borderRadius: 13, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', ...shadow(8) },
  mid: { flex: 1, justifyContent: 'center' },
  h2: { fontFamily: fonts.display, fontSize: 26, color: colors.ink, marginBottom: 6 },
  sub: { fontFamily: fonts.body, fontSize: 13.5, color: colors.muted, marginBottom: 24, lineHeight: 20 },
  phoneRow: { flexDirection: 'row', gap: 9 },
  cc: { backgroundColor: '#fff', borderWidth: 1, borderColor: colors.line, borderRadius: 14, paddingHorizontal: 13, justifyContent: 'center' },
  ccTxt: { fontFamily: fonts.bodyBold, fontSize: 15, color: colors.ink },
  phoneInput: { flex: 1, backgroundColor: '#fff', borderWidth: 1, borderColor: colors.line, borderRadius: 14, paddingHorizontal: 15, paddingVertical: 14, fontFamily: fonts.body, fontSize: 16, color: colors.ink },
  otp: { flexDirection: 'row', gap: 11, justifyContent: 'center', marginVertical: 6 },
  otpBox: { width: 58, height: 66, backgroundColor: '#fff', borderWidth: 1.5, borderColor: colors.line, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  otpFill: { borderColor: colors.coral },
  otpTxt: { fontFamily: fonts.display, fontSize: 26, color: colors.ink },
  resend: { textAlign: 'center', fontFamily: fonts.body, fontSize: 12.5, color: colors.muted, marginTop: 18 },
  foot: { paddingBottom: 30 },
  btn: { backgroundColor: colors.coral, borderRadius: 16, paddingVertical: 16, alignItems: 'center', ...shadow(14) },
  btnTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 15 },
});
