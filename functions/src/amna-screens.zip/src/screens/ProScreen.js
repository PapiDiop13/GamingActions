import React, { useState } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { colors, fonts, shadow } from '../../theme';
import { requests } from '../data/pros';

const DURATIONS = ['30 min', '1 h', '2 h', 'Ce soir'];

export default function ProScreen({ navigation }) {
  const [live, setLive] = useState(true);
  const [duration, setDuration] = useState('1 h');

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={styles.head}>
          <Text style={styles.title}>Mode Pro</Text>
          <TouchableOpacity style={styles.gear} onPress={() => navigation.navigate('ProProfileEdit')}>
            <Feather name="edit-2" size={18} color={colors.ink} />
          </TouchableOpacity>
        </View>

        {/* Carte Go Live (hero sombre) */}
        <View style={styles.liveCard}>
          <View style={styles.row1}>
            <Image source={{ uri: 'https://i.pravatar.cc/120?img=68' }} style={styles.av} />
            <View>
              <Text style={styles.who}>Modou Faye</Text>
              <Text style={styles.whoSub}>Plomberie · Dakar, Sacré-Cœur</Text>
            </View>
          </View>

          <View style={[styles.pill, live ? styles.pillOn : styles.pillOff]}>
            <View style={[styles.pillDot, { backgroundColor: live ? colors.coral : '#5d7176' }]} />
            <Text style={[styles.pillTxt, { color: live ? '#FF9A78' : '#9FB6B7' }]}>
              {live ? `En live · se coupe dans 1 h 42` : 'Tu es hors ligne'}
            </Text>
          </View>

          <View style={styles.toggleWrap}>
            <View style={{ flex: 1 }}>
              <Text style={styles.toggleLbl}>Passer en live</Text>
              <Text style={styles.toggleSub}>Les clients autour te voient et te contactent.</Text>
            </View>
            <TouchableOpacity style={[styles.switch, live && styles.switchOn]} onPress={() => setLive((v) => !v)} activeOpacity={0.9}>
              <View style={[styles.knob, live && styles.knobOn]} />
            </TouchableOpacity>
          </View>

          {live && (
            <View style={styles.durWrap}>
              <Text style={styles.durLbl}>Se couper automatiquement après :</Text>
              <View style={styles.durChips}>
                {DURATIONS.map((d) => (
                  <TouchableOpacity key={d} style={[styles.durChip, duration === d && styles.durChipOn]} onPress={() => setDuration(d)}>
                    <Text style={[styles.durChipTxt, duration === d && styles.durChipTxtOn]}>{d}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}

          <View style={styles.lockNote}>
            <Feather name="lock" size={16} color="#5fd6c8" />
            <Text style={styles.lockTxt}>Tu peux verrouiller ton téléphone, tu restes en live jusqu'à l'heure de fin.</Text>
          </View>
        </View>

        {/* Stats */}
        <View style={styles.stats}>
          <Stat v="47" l="Vues aujourd'hui" />
          <Stat v="9" l="Contacts" />
          <Stat v="4.9 ★" l="Ta note" />
        </View>

        {/* Demandes */}
        <View style={styles.section}>
          <View style={styles.secHead}>
            <Text style={styles.secTitle}>Demandes</Text>
            <Text style={styles.secCount}>{requests.length} nouvelles</Text>
          </View>
          {requests.map((r) => (
            <View key={r.id} style={styles.req}>
              <View style={styles.reqTop}>
                <Image source={{ uri: `https://i.pravatar.cc/80?img=${r.img}` }} style={styles.reqAv} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.reqNm}>{r.name}</Text>
                  <Text style={styles.reqMeta}>{r.meta}</Text>
                </View>
                <Text style={styles.reqTime}>{r.time}</Text>
              </View>
              <Text style={styles.reqMsg}>« {r.msg} »</Text>
              <View style={styles.reqActs}>
                <TouchableOpacity style={[styles.reqBtn, styles.reqAcc]} onPress={() => navigation.navigate('Chat', { id: 'modou' })}>
                  <Text style={styles.reqAccTxt}>Accepter</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.reqBtn, styles.reqDec]}>
                  <Text style={styles.reqDecTxt}>Refuser</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>

        {/* Tout gratuit (abonnements masqués) */}
        <View style={styles.freeCard}>
          <View style={styles.freeIc}><Text style={{ fontSize: 22 }}>🎉</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.freeTitle}>Tout est gratuit</Text>
            <Text style={styles.freeSub}>Toutes les fonctionnalités sont offertes pendant le lancement d'Amna.</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function Stat({ v, l }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.statV}>{v}</Text>
      <Text style={styles.statL}>{l}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingTop: 8 },
  title: { fontFamily: fonts.display, fontSize: 22, color: colors.ink },
  gear: { width: 40, height: 40, borderRadius: 13, backgroundColor: colors.card, alignItems: 'center', justifyContent: 'center', ...shadow(8) },

  liveCard: { margin: 18, backgroundColor: colors.inkSoft, borderRadius: 24, padding: 22, ...shadow(20) },
  row1: { flexDirection: 'row', alignItems: 'center', gap: 13 },
  av: { width: 56, height: 56, borderRadius: 16, borderWidth: 2, borderColor: 'rgba(255,255,255,0.15)', backgroundColor: '#1c474e' },
  who: { fontFamily: fonts.bodyBold, fontSize: 16, color: '#fff' },
  whoSub: { fontFamily: fonts.body, fontSize: 12.5, color: '#9FB6B7', marginTop: 2 },
  pill: { flexDirection: 'row', alignItems: 'center', gap: 7, alignSelf: 'flex-start', paddingHorizontal: 11, paddingVertical: 6, borderRadius: 11, marginTop: 18 },
  pillOn: { backgroundColor: 'rgba(255,86,48,0.18)' },
  pillOff: { backgroundColor: 'rgba(255,255,255,0.08)' },
  pillDot: { width: 8, height: 8, borderRadius: 4 },
  pillTxt: { fontFamily: fonts.bodyBold, fontSize: 12 },
  toggleWrap: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12, marginTop: 18, backgroundColor: 'rgba(0,0,0,0.2)', borderRadius: 18, padding: 15 },
  toggleLbl: { fontFamily: fonts.bodyBold, fontSize: 14.5, color: '#fff' },
  toggleSub: { fontFamily: fonts.body, fontSize: 11.5, color: '#9FB6B7', marginTop: 3, lineHeight: 16 },
  switch: { width: 62, height: 34, borderRadius: 17, backgroundColor: '#33565c', padding: 3, justifyContent: 'center' },
  switchOn: { backgroundColor: colors.coral },
  knob: { width: 28, height: 28, borderRadius: 14, backgroundColor: '#fff' },
  knobOn: { alignSelf: 'flex-end' },
  durWrap: { marginTop: 14 },
  durLbl: { fontFamily: fonts.bodySemi, fontSize: 11.5, color: '#9FB6B7', marginBottom: 8 },
  durChips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  durChip: { backgroundColor: 'rgba(255,255,255,0.07)', borderWidth: 1.5, borderColor: 'transparent', borderRadius: 11, paddingHorizontal: 13, paddingVertical: 9 },
  durChipOn: { backgroundColor: 'rgba(255,86,48,0.18)', borderColor: colors.coral },
  durChipTxt: { fontFamily: fonts.bodyBold, fontSize: 12.5, color: '#cfe' },
  durChipTxtOn: { color: '#FF9A78' },
  lockNote: { flexDirection: 'row', gap: 9, alignItems: 'flex-start', marginTop: 14, backgroundColor: 'rgba(15,179,160,0.13)', borderRadius: 14, padding: 11 },
  lockTxt: { flex: 1, fontFamily: fonts.body, fontSize: 12, color: '#bfe3de', lineHeight: 18 },

  stats: { flexDirection: 'row', gap: 11, marginHorizontal: 18 },
  stat: { flex: 1, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.line, borderRadius: 18, padding: 15 },
  statV: { fontFamily: fonts.display, fontSize: 24, color: colors.ink },
  statL: { fontFamily: fonts.bodySemi, fontSize: 11, color: colors.muted, marginTop: 3 },

  section: { marginHorizontal: 18, marginTop: 22 },
  secHead: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 11 },
  secTitle: { fontFamily: fonts.display, fontSize: 16, color: colors.ink },
  secCount: { fontFamily: fonts.bodyBold, fontSize: 11, color: colors.coral },
  req: { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.line, borderRadius: 18, padding: 13, marginBottom: 10 },
  reqTop: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  reqAv: { width: 42, height: 42, borderRadius: 12, backgroundColor: '#cdd9d7' },
  reqNm: { fontFamily: fonts.bodyBold, fontSize: 14, color: colors.ink },
  reqMeta: { fontFamily: fonts.body, fontSize: 11.5, color: colors.muted, marginTop: 2 },
  reqTime: { fontFamily: fonts.body, fontSize: 10.5, color: colors.muted2 },
  reqMsg: { fontFamily: fonts.body, fontSize: 12.5, color: colors.inkSoft, marginTop: 9, marginBottom: 11, lineHeight: 18 },
  reqActs: { flexDirection: 'row', gap: 9 },
  reqBtn: { flex: 1, borderRadius: 11, paddingVertical: 10, alignItems: 'center' },
  reqAcc: { backgroundColor: colors.coral },
  reqAccTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 12.5 },
  reqDec: { backgroundColor: '#eef2f1' },
  reqDecTxt: { color: colors.inkSoft, fontFamily: fonts.bodyBold, fontSize: 12.5 },

  freeCard: { flexDirection: 'row', alignItems: 'center', gap: 14, marginHorizontal: 18, marginTop: 22, backgroundColor: '#E6F4F1', borderRadius: 20, padding: 18 },
  freeIc: { width: 46, height: 46, borderRadius: 14, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  freeTitle: { fontFamily: fonts.display, fontSize: 15.5, color: colors.tealD },
  freeSub: { fontFamily: fonts.body, fontSize: 12, color: colors.tealD, marginTop: 3, lineHeight: 17, opacity: 0.85 },
});
