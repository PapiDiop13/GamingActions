import React, { useState } from 'react';
import { View, Text, TextInput, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { colors, fonts, shadow } from '../../theme';

const TRADES = ['🔧 Plombier', '🚗 Mécano', '💈 Coiffeur', '⚡ Électricien', '🧵 Couturier', '🧹 Ménage'];
const PRICE_TYPES = ['Forfait', "À l'heure", 'Sur devis'];

export default function ProProfileEditScreen({ navigation }) {
  const [trade, setTrade] = useState('🔧 Plombier');
  const [priceType, setPriceType] = useState('Forfait');
  const [name, setName] = useState('Modou Faye');
  const [phone, setPhone] = useState('+221 77 123 45 67');
  const [zone, setZone] = useState('Dakar, Sacré-Cœur');
  const [bio, setBio] = useState("Plombier depuis 9 ans. Fuites, chauffe-eau, débouchage. Travail rapide et soigné.");
  const [price, setPrice] = useState('7 500');

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <View style={styles.head}>
        <TouchableOpacity style={styles.back} onPress={() => navigation.goBack()}>
          <Feather name="chevron-left" size={20} color={colors.ink} />
        </TouchableOpacity>
        <Text style={styles.title}>Modifier le profil</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 18, paddingBottom: 40 }}>
        {/* Photos */}
        <Text style={styles.label}>Profil & bannière</Text>
        <View style={styles.photoRow}>
          <View style={styles.photoBox}>
            <Image source={{ uri: 'https://i.pravatar.cc/120?img=68' }} style={styles.photoAv} />
            <View style={styles.photoEdit}><Feather name="camera" size={13} color="#fff" /></View>
          </View>
          <TouchableOpacity style={styles.bannerBox}>
            <Feather name="image" size={20} color={colors.coral} />
            <Text style={styles.bannerTxt}>Changer la bannière</Text>
          </TouchableOpacity>
        </View>

        {/* Métier */}
        <Text style={[styles.label, { marginTop: 20 }]}>Métier</Text>
        <View style={styles.chips}>
          {TRADES.map((t) => (
            <TouchableOpacity key={t} style={[styles.chip, trade === t && styles.chipOn]} onPress={() => setTrade(t)}>
              <Text style={[styles.chipTxt, trade === t && styles.chipTxtOn]}>{t}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Field label="Nom complet" value={name} onChange={setName} />
        <Field label="Téléphone" value={phone} onChange={setPhone} />
        <Field label="Zone / quartier" value={zone} onChange={setZone} />
        <Field label="Présentation" value={bio} onChange={setBio} multiline />

        <Text style={styles.label}>Prix moyen (FCFA)</Text>
        <TextInput style={styles.input} value={price} onChangeText={setPrice} keyboardType="number-pad" />

        <Text style={[styles.label, { marginTop: 14 }]}>Type de tarif</Text>
        <View style={styles.chips}>
          {PRICE_TYPES.map((t) => (
            <TouchableOpacity key={t} style={[styles.seg, priceType === t && styles.segOn]} onPress={() => setPriceType(t)}>
              <Text style={[styles.segTxt, priceType === t && styles.segTxtOn]}>{t}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity style={styles.save} onPress={() => navigation.goBack()} activeOpacity={0.9}>
          <Text style={styles.saveTxt}>Enregistrer</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

function Field({ label, value, onChange, multiline }) {
  return (
    <View style={{ marginTop: 14 }}>
      <Text style={styles.label}>{label}</Text>
      <TextInput style={[styles.input, multiline && styles.inputMulti]} value={value} onChangeText={onChange} multiline={multiline} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  head: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingTop: 6, paddingBottom: 8 },
  back: { width: 40, height: 40, borderRadius: 13, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', ...shadow(8) },
  title: { fontFamily: fonts.display, fontSize: 20, color: colors.ink },
  label: { fontFamily: fonts.bodyBold, fontSize: 12, color: colors.inkSoft, marginBottom: 7 },
  photoRow: { flexDirection: 'row', gap: 11, alignItems: 'stretch' },
  photoBox: { width: 76, height: 76 },
  photoAv: { width: 76, height: 76, borderRadius: 18, backgroundColor: '#cdd9d7' },
  photoEdit: { position: 'absolute', bottom: -4, right: -4, width: 26, height: 26, borderRadius: 13, backgroundColor: colors.coral, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: colors.bg },
  bannerBox: { flex: 1, borderWidth: 2, borderColor: colors.muted2, borderStyle: 'dashed', borderRadius: 16, alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: '#fff' },
  bannerTxt: { fontFamily: fonts.bodySemi, fontSize: 12, color: colors.muted },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { backgroundColor: '#fff', borderWidth: 1.5, borderColor: colors.line, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 9 },
  chipOn: { borderColor: colors.coral, backgroundColor: '#FFF4F0' },
  chipTxt: { fontFamily: fonts.bodySemi, fontSize: 12.5, color: colors.inkSoft },
  chipTxtOn: { color: colors.coral },
  input: { backgroundColor: '#fff', borderWidth: 1, borderColor: colors.line, borderRadius: 13, paddingHorizontal: 14, paddingVertical: 13, fontFamily: fonts.body, fontSize: 14.5, color: colors.ink },
  inputMulti: { height: 84, textAlignVertical: 'top' },
  seg: { backgroundColor: '#fff', borderWidth: 1.5, borderColor: colors.line, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 11 },
  segOn: { borderColor: colors.coral, backgroundColor: '#FFF4F0' },
  segTxt: { fontFamily: fonts.bodySemi, fontSize: 13, color: colors.inkSoft },
  segTxtOn: { color: colors.coral },
  save: { backgroundColor: colors.coral, borderRadius: 16, paddingVertical: 15, alignItems: 'center', marginTop: 24, ...shadow(14) },
  saveTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 15 },
});
