import React, { useRef, useState } from 'react';
import {
  View, Text, TextInput, Image, ScrollView, TouchableOpacity,
  StyleSheet, Animated, PanResponder, Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import MapView, { Marker, Circle, Polyline, PROVIDER_DEFAULT } from 'react-native-maps';
import { colors, fonts, shadow } from '../../theme';
import { pros as ALL } from '../data/pros';

const { height: SCREEN_H } = Dimensions.get('window');
const USER = { latitude: 14.708, longitude: -17.458 };
const REGION = { ...USER, latitudeDelta: 0.045, longitudeDelta: 0.045 };
const PEEK = 168;
const EXPANDED = Math.round(SCREEN_H * 0.52);

export default function MapScreen({ navigation }) {
  const mapRef = useRef(null);
  const [selected, setSelected] = useState(null);
  const [liveOnly, setLiveOnly] = useState(false);
  const [sortMode, setSortMode] = useState('km');
  const [radiusKm, setRadiusKm] = useState(3);
  const [radarOn, setRadarOn] = useState(false);

  const sheetH = useRef(new Animated.Value(PEEK)).current;
  const sheetStart = useRef(PEEK);
  const pan = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dy) > 4,
      onPanResponderGrant: () => sheetH.stopAnimation((v) => (sheetStart.current = v)),
      onPanResponderMove: (_, g) => {
        let h = sheetStart.current - g.dy;
        h = Math.max(PEEK - 20, Math.min(EXPANDED + 20, h));
        sheetH.setValue(h);
      },
      onPanResponderRelease: (_, g) => {
        const h = sheetStart.current - g.dy;
        const target = h > (PEEK + EXPANDED) / 2 ? EXPANDED : PEEK;
        Animated.spring(sheetH, { toValue: target, useNativeDriver: false, bounciness: 4 }).start();
      },
    })
  ).current;

  const num = (s) => parseFloat(String(s).replace(/[^\d,.]/g, '').replace(',', '.'));
  const visible = ALL.filter((p) => (!liveOnly || p.live) && p.km <= radiusKm);
  const ranked = [...visible]
    .sort((a, b) => (sortMode === 'km' ? a.km - b.km : sortMode === 'prix' ? num(a.price) - num(b.price) : b.rate - a.rate))
    .sort((a, b) => (b.prem ? 1 : 0) - (a.prem ? 1 : 0));
  const selPro = ALL.find((p) => p.id === selected);

  const select = (p) => {
    setSelected(p.id);
    mapRef.current?.animateToRegion(
      { latitude: (p.lat + USER.latitude) / 2, longitude: (p.lng + USER.longitude) / 2, latitudeDelta: 0.04, longitudeDelta: 0.04 },
      400
    );
    Animated.spring(sheetH, { toValue: PEEK, useNativeDriver: false, bounciness: 4 }).start();
  };
  const deselect = () => setSelected(null);

  const findNearest = () => {
    deselect();
    setRadarOn(true);
    setTimeout(() => {
      setRadarOn(false);
      const live = visible.filter((p) => p.live).sort((a, b) => a.km - b.km);
      if (live[0]) select(live[0]);
    }, 1300);
  };

  const recenter = () => { deselect(); mapRef.current?.animateToRegion(REGION, 500); };
  const cycleSort = () => setSortMode((s) => (s === 'km' ? 'prix' : s === 'prix' ? 'note' : 'km'));
  const sortLabel = sortMode === 'km' ? '↕ Distance' : sortMode === 'prix' ? '↕ Prix' : '↕ Note';

  return (
    <View style={styles.root}>
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        provider={PROVIDER_DEFAULT}
        initialRegion={REGION}
        showsCompass={false}
        onPress={deselect}
      >
        <Circle center={USER} radius={radiusKm * 1000} strokeColor="rgba(15,179,160,0.55)" fillColor="rgba(15,179,160,0.08)" strokeWidth={2} />
        <Marker coordinate={USER} anchor={{ x: 0.5, y: 0.5 }}>
          <View style={styles.meDot} />
        </Marker>
        {selPro && (
          <Polyline coordinates={[USER, { latitude: selPro.lat, longitude: selPro.lng }]} strokeColor={colors.coral} strokeWidth={4} lineDashPattern={[2, 8]} />
        )}
        {visible.map((p) => {
          const ring = p.prem ? colors.gold : p.live ? colors.coral : '#B9C4C2';
          const sel = selected === p.id;
          return (
            <Marker key={p.id} coordinate={{ latitude: p.lat, longitude: p.lng }} anchor={{ x: 0.5, y: 1 }} onPress={() => select(p)}>
              <View style={[styles.pin, sel && { transform: [{ scale: 1.16 }] }]}>
                <View style={[styles.pinRing, { borderColor: ring }, sel && styles.pinRingSel]}>
                  <Image source={{ uri: p.avatar }} style={styles.pinImg} />
                </View>
                <View style={[styles.pinTail, { borderTopColor: ring }]} />
              </View>
            </Marker>
          );
        })}
      </MapView>

      {radarOn && <RadarOverlay />}

      <SafeAreaView edges={['top']} style={styles.top} pointerEvents="box-none">
        <View style={styles.searchRow}>
          <View style={styles.search}>
            <Feather name="search" size={18} color={colors.muted} />
            <TextInput placeholder="Plombier près de moi…" placeholderTextColor={colors.muted2} style={styles.searchInput} />
          </View>
          <View style={styles.toggle}>
            <View style={[styles.tBtn, styles.tBtnOn]}>
              <Feather name="map" size={14} color="#fff" />
              <Text style={styles.tBtnTxtOn}>Carte</Text>
            </View>
            <TouchableOpacity style={styles.tBtn} onPress={() => Animated.spring(sheetH, { toValue: EXPANDED, useNativeDriver: false }).start()}>
              <Text style={styles.tBtnTxt}>Liste</Text>
            </TouchableOpacity>
          </View>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
          {['🔧 Plombier', '🚗 Mécano', '💈 Coiffeur', '⚡ Électricien', '🍽️ Resto', '🧹 Ménage'].map((c, i) => (
            <View key={c} style={[styles.chip, i === 0 && styles.chipOn]}>
              <Text style={[styles.chipTxt, i === 0 && styles.chipTxtOn]}>{c}</Text>
            </View>
          ))}
        </ScrollView>
        <View style={styles.radiusRow}>
          <Text style={styles.radiusLbl}>Rayon</Text>
          {[1, 2, 3, 5].map((r) => (
            <TouchableOpacity key={r} style={[styles.radChip, radiusKm === r && styles.radChipOn]} onPress={() => { setRadiusKm(r); deselect(); }}>
              <Text style={[styles.radChipTxt, radiusKm === r && styles.radChipTxtOn]}>{r} km</Text>
            </TouchableOpacity>
          ))}
        </View>
      </SafeAreaView>

      <View style={styles.fabs}>
        <TouchableOpacity style={styles.fab} onPress={recenter}>
          <Feather name="navigation" size={19} color={colors.ink} />
        </TouchableOpacity>
        <TouchableOpacity style={[styles.fab, liveOnly && styles.fabOn]} onPress={() => { setLiveOnly((v) => !v); deselect(); }}>
          <Feather name="zap" size={19} color={liveOnly ? '#fff' : colors.ink} />
        </TouchableOpacity>
      </View>

      {!selPro && (
        <TouchableOpacity style={[styles.nearest, { bottom: PEEK + 14 }]} onPress={findNearest} activeOpacity={0.9}>
          <View style={styles.nearestB}><Feather name="crosshair" size={13} color="#fff" /></View>
          <Text style={styles.nearestTxt}>Le plus proche dispo</Text>
        </TouchableOpacity>
      )}

      {selPro && (
        <View style={[styles.preview, { bottom: PEEK + 14 }]}>
          <TouchableOpacity style={styles.previewClose} onPress={deselect}>
            <Feather name="x" size={16} color={colors.muted} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.prTop} activeOpacity={0.9} onPress={() => navigation.navigate('Profile', { id: selPro.id })}>
            <Image source={{ uri: selPro.avatar }} style={styles.prAv} />
            <View style={{ flex: 1 }}>
              <View style={styles.prNmRow}>
                <Text style={styles.prNm}>{selPro.name}</Text>
                {selPro.prem && <View style={styles.prPb}><Text style={styles.prPbTxt}>PRO+</Text></View>}
              </View>
              <Text style={styles.prSub}>{selPro.trade.split(' · ')[0]}</Text>
              <Text style={styles.prRate}>★ {selPro.rate}</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={styles.prPrice}>{selPro.price}</Text>
              <Text style={styles.prPriceL}>prix moyen</Text>
            </View>
          </TouchableOpacity>
          <View style={styles.etaRow}>
            {[['user', `${selPro.walk} min`, 'à pied'], ['truck', `${selPro.drive} min`, 'en voiture'], ['map-pin', `${selPro.km.toString().replace('.', ',')} km`, 'distance']].map(([ic, v, l]) => (
              <View key={l} style={styles.eta}>
                <Feather name={ic} size={16} color={colors.tealD} />
                <View>
                  <Text style={styles.etaV}>{v}</Text>
                  <Text style={styles.etaL}>{l}</Text>
                </View>
              </View>
            ))}
          </View>
          <View style={styles.acts}>
            <TouchableOpacity style={[styles.act, styles.actMsg]} onPress={() => navigation.navigate('Chat', { id: selPro.id })}>
              <Feather name="message-circle" size={17} color="#fff" />
              <Text style={styles.actTxt}>Message</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.act, styles.actCall]} onPress={() => navigation.navigate('Call', { id: selPro.id })}>
              <Feather name="phone" size={17} color="#fff" />
              <Text style={styles.actTxt}>Appeler</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      <Animated.View style={[styles.sheet, { height: sheetH }]}>
        <View {...pan.panHandlers} style={styles.sheetHandleZone}>
          <View style={styles.grip} />
          <View style={styles.sheetHead}>
            <Text style={styles.sheetTitle}>{ranked.length} plombier{ranked.length > 1 ? 's' : ''} près de toi</Text>
            <TouchableOpacity style={styles.sortBtn} onPress={cycleSort}>
              <Text style={styles.sortTxt}>{sortLabel}</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.sheetSub}>
            {sortMode === 'km' ? 'Du plus proche au plus loin' : sortMode === 'prix' ? 'Triés par prix' : 'Triés par note'} · rayon {radiusKm} km
          </Text>
        </View>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 14, paddingBottom: 20, gap: 10 }}>
          {ranked.map((p) => (
            <TouchableOpacity key={p.id} style={[styles.card, p.prem && styles.cardBoost, selected === p.id && styles.cardActive]} activeOpacity={0.9} onPress={() => select(p)}>
              <View>
                <Image source={{ uri: p.avatar }} style={styles.cardAv} />
                {p.live && <View style={styles.cardLv} />}
              </View>
              <View style={{ flex: 1 }}>
                <View style={styles.cardNmRow}>
                  <Text style={styles.cardNm}>{p.name}</Text>
                  {p.prem && <View style={styles.prPb}><Text style={styles.prPbTxt}>PRO+</Text></View>}
                </View>
                <Text style={styles.cardSub}>{p.trade.split(' · ')[0]} · {p.live ? 'En live' : 'Hors ligne'}</Text>
                <View style={styles.cardMeta}>
                  <Text style={styles.cardStar}>★ {p.rate}</Text>
                  <View style={styles.cardWalk}>
                    <Feather name="user" size={11} color={colors.tealD} />
                    <Text style={styles.cardWalkTxt}>{p.walk} min</Text>
                  </View>
                </View>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={styles.cardKm}>{p.km.toString().replace('.', ',')}<Text style={styles.cardKmU}> km</Text></Text>
                <Text style={styles.cardPrice}>{p.price}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </Animated.View>
    </View>
  );
}

function RadarOverlay() {
  const pulses = [useRef(new Animated.Value(0)).current, useRef(new Animated.Value(0)).current, useRef(new Animated.Value(0)).current];
  React.useEffect(() => {
    const anims = pulses.map((v, i) =>
      Animated.loop(Animated.sequence([Animated.delay(i * 350), Animated.timing(v, { toValue: 1, duration: 1300, useNativeDriver: true })]))
    );
    anims.forEach((a) => a.start());
    return () => anims.forEach((a) => a.stop());
  }, []);
  return (
    <View pointerEvents="none" style={styles.radar}>
      {pulses.map((v, i) => (
        <Animated.View key={i} style={[styles.radarRing, { opacity: v.interpolate({ inputRange: [0, 1], outputRange: [0.5, 0] }), transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [0.3, 2.6] }) }] }]} />
      ))}
      <View style={styles.radarCore} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.land },
  meDot: { width: 18, height: 18, borderRadius: 9, backgroundColor: colors.teal, borderWidth: 3, borderColor: '#fff', ...shadow(6) },
  pin: { alignItems: 'center' },
  pinRing: { width: 46, height: 46, borderRadius: 23, borderWidth: 3, backgroundColor: '#fff', overflow: 'hidden', ...shadow(6) },
  pinRingSel: { borderWidth: 4 },
  pinImg: { width: '100%', height: '100%' },
  pinTail: { width: 0, height: 0, borderLeftWidth: 6, borderRightWidth: 6, borderTopWidth: 8, borderLeftColor: 'transparent', borderRightColor: 'transparent', marginTop: -2 },
  radar: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' },
  radarRing: { position: 'absolute', width: 200, height: 200, borderRadius: 100, borderWidth: 2, borderColor: colors.teal },
  radarCore: { width: 16, height: 16, borderRadius: 8, backgroundColor: colors.teal, borderWidth: 3, borderColor: '#fff' },
  top: { position: 'absolute', top: 0, left: 0, right: 0, paddingHorizontal: 14, paddingTop: 4 },
  searchRow: { flexDirection: 'row', gap: 9, alignItems: 'center' },
  search: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 9, backgroundColor: colors.card, borderRadius: 15, paddingHorizontal: 14, paddingVertical: 11, ...shadow(8) },
  searchInput: { flex: 1, fontFamily: fonts.body, fontSize: 14, color: colors.ink, padding: 0 },
  toggle: { flexDirection: 'row', backgroundColor: colors.card, borderRadius: 14, padding: 4, ...shadow(8) },
  tBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 11, paddingVertical: 8, borderRadius: 10 },
  tBtnOn: { backgroundColor: colors.ink },
  tBtnTxt: { fontFamily: fonts.bodyBold, fontSize: 12, color: colors.muted },
  tBtnTxtOn: { fontFamily: fonts.bodyBold, fontSize: 12, color: '#fff' },
  chips: { gap: 8, paddingVertical: 10 },
  chip: { backgroundColor: colors.card, borderRadius: 12, paddingHorizontal: 13, paddingVertical: 9, ...shadow(8) },
  chipOn: { backgroundColor: colors.ink },
  chipTxt: { fontFamily: fonts.bodySemi, fontSize: 12.5, color: colors.inkSoft },
  chipTxtOn: { color: '#fff' },
  radiusRow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  radiusLbl: { fontFamily: fonts.bodyBold, fontSize: 11, color: colors.inkSoft, marginRight: 2 },
  radChip: { backgroundColor: colors.card, borderRadius: 10, paddingHorizontal: 11, paddingVertical: 7, ...shadow(6) },
  radChipOn: { backgroundColor: colors.coral },
  radChipTxt: { fontFamily: fonts.bodyBold, fontSize: 11.5, color: colors.muted },
  radChipTxtOn: { color: '#fff' },
  fabs: { position: 'absolute', right: 14, top: SCREEN_H * 0.32, gap: 9 },
  fab: { width: 42, height: 42, borderRadius: 13, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', ...shadow(10) },
  fabOn: { backgroundColor: colors.coral },
  nearest: { position: 'absolute', alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 9, backgroundColor: colors.ink, borderRadius: 16, paddingHorizontal: 20, paddingVertical: 13, ...shadow(16) },
  nearestB: { width: 22, height: 22, borderRadius: 11, backgroundColor: colors.coral, alignItems: 'center', justifyContent: 'center' },
  nearestTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 13.5 },
  preview: { position: 'absolute', left: 14, right: 14, backgroundColor: '#fff', borderRadius: 22, padding: 13, ...shadow(18) },
  previewClose: { position: 'absolute', top: 11, right: 11, width: 26, height: 26, borderRadius: 13, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', zIndex: 2 },
  prTop: { flexDirection: 'row', gap: 12, alignItems: 'center' },
  prAv: { width: 58, height: 58, borderRadius: 16, backgroundColor: '#cdd9d7' },
  prNmRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  prNm: { fontFamily: fonts.bodyBold, fontSize: 15, color: colors.ink },
  prPb: { backgroundColor: colors.gold, paddingHorizontal: 5, paddingVertical: 2, borderRadius: 6 },
  prPbTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 8.5 },
  prSub: { fontFamily: fonts.body, fontSize: 12, color: colors.muted, marginTop: 2 },
  prRate: { fontFamily: fonts.bodyBold, fontSize: 12, color: colors.gold, marginTop: 6 },
  prPrice: { fontFamily: fonts.mono, fontSize: 15, color: colors.ink },
  prPriceL: { fontFamily: fonts.bodySemi, fontSize: 9, color: colors.muted2 },
  etaRow: { flexDirection: 'row', gap: 9, marginTop: 12 },
  eta: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: colors.bg, borderRadius: 13, paddingHorizontal: 11, paddingVertical: 9 },
  etaV: { fontFamily: fonts.bodyBold, fontSize: 13, color: colors.ink },
  etaL: { fontFamily: fonts.bodySemi, fontSize: 10, color: colors.muted },
  acts: { flexDirection: 'row', gap: 9, marginTop: 11 },
  act: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, borderRadius: 13, paddingVertical: 12 },
  actMsg: { backgroundColor: colors.ink },
  actCall: { backgroundColor: colors.coral },
  actTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 13.5 },
  sheet: { position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: colors.card, borderTopLeftRadius: 26, borderTopRightRadius: 26, ...shadow(20) },
  sheetHandleZone: { paddingTop: 9 },
  grip: { width: 42, height: 5, borderRadius: 99, backgroundColor: colors.line, alignSelf: 'center', marginBottom: 8 },
  sheetHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18 },
  sheetTitle: { fontFamily: fonts.display, fontSize: 16, color: colors.ink },
  sortBtn: { backgroundColor: colors.bg, borderRadius: 10, paddingHorizontal: 11, paddingVertical: 7 },
  sortTxt: { fontFamily: fonts.bodyBold, fontSize: 11.5, color: colors.coral },
  sheetSub: { fontFamily: fonts.bodySemi, fontSize: 12, color: colors.muted, paddingHorizontal: 18, paddingTop: 4, paddingBottom: 10 },
  card: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#fff', borderWidth: 1, borderColor: colors.line, borderRadius: 18, padding: 11 },
  cardBoost: { borderColor: 'rgba(230,154,18,0.4)', backgroundColor: '#FFFCF5' },
  cardActive: { borderColor: colors.coral },
  cardAv: { width: 52, height: 52, borderRadius: 15, backgroundColor: '#cdd9d7' },
  cardLv: { position: 'absolute', right: -3, bottom: -3, width: 14, height: 14, borderRadius: 7, backgroundColor: colors.coral, borderWidth: 2.5, borderColor: '#fff' },
  cardNmRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  cardNm: { fontFamily: fonts.bodyBold, fontSize: 14, color: colors.ink },
  cardSub: { fontFamily: fonts.body, fontSize: 11.5, color: colors.muted, marginTop: 2 },
  cardMeta: { flexDirection: 'row', alignItems: 'center', gap: 9, marginTop: 5 },
  cardStar: { fontFamily: fonts.bodyBold, fontSize: 11.5, color: colors.gold },
  cardWalk: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  cardWalkTxt: { fontFamily: fonts.bodyBold, fontSize: 11.5, color: colors.tealD },
  cardKm: { fontFamily: fonts.display, fontSize: 16, color: colors.ink },
  cardKmU: { fontFamily: fonts.bodySemi, fontSize: 10, color: colors.muted },
  cardPrice: { fontFamily: fonts.mono, fontSize: 11, color: colors.muted },
});
