import React, { useState } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { colors, fonts } from '../../theme';

export default function AccountScreen({ navigation }) {
  const [lang, setLang] = useState('FR');

  const rows = [
    { ic: 'bookmark', tint: '#FFF0EC', color: colors.coral, label: 'Mes favoris', go: 'Favoris' },
    { ic: 'message-circle', tint: '#E7F1FB', color: '#2b7fd0', label: 'Mes messages', tab: 'Messages' },
    { ic: 'zap', tint: '#E6F4F1', color: colors.tealD, label: 'Mon espace Pro', tab: 'Pro' },
    { ic: 'bell', tint: '#F1ECFB', color: '#7c5fd0', label: 'Notifications', go: 'Notifications' },
    { ic: 'help-circle', tint: '#EEF2F1', color: colors.muted, label: 'Aide & support' },
  ];

  return (
    <SafeAreaView style={styles.root} edges={[]}>
      <View style={styles.top}>
        <Image source={{ uri: 'https://i.pravatar.cc/120?img=5' }} style={styles.av} />
        <View>
          <Text style={styles.name}>Aminata Sow</Text>
          <Text style={styles.email}>+221 77 123 45 67</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: 14, paddingBottom: 24 }} showsVerticalScrollIndicator={false}>
        {rows.map((r) => (
          <TouchableOpacity
            key={r.label}
            style={styles.row}
            activeOpacity={0.8}
            onPress={() => (r.go ? navigation.navigate(r.go) : r.tab ? navigation.navigate(r.tab) : null)}
          >
            <View style={[styles.rowIc, { backgroundColor: r.tint }]}>
              <Feather name={r.ic} size={18} color={r.color} />
            </View>
            <Text style={styles.rowLabel}>{r.label}</Text>
            <Feather name="chevron-right" size={18} color={colors.muted2} />
          </TouchableOpacity>
        ))}

        {/* Langue */}
        <View style={styles.row}>
          <View style={[styles.rowIc, { backgroundColor: '#EDEFF5' }]}>
            <Feather name="globe" size={18} color="#5b6bb0" />
          </View>
          <Text style={styles.rowLabel}>Langue</Text>
          <View style={styles.langToggle}>
            {['FR', 'EN'].map((l) => (
              <TouchableOpacity key={l} style={[styles.langBtn, lang === l && styles.langBtnOn]} onPress={() => setLang(l)}>
                <Text style={[styles.langTxt, lang === l && styles.langTxtOn]}>{l}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Déconnexion */}
        <TouchableOpacity
          style={styles.row}
          activeOpacity={0.8}
          onPress={() => navigation.getParent()?.reset({ index: 0, routes: [{ name: 'Onboarding' }] })}
        >
          <View style={[styles.rowIc, { backgroundColor: '#FDEDE9' }]}>
            <Feather name="log-out" size={18} color="#E8441F" />
          </View>
          <Text style={[styles.rowLabel, { color: '#E8441F' }]}>Déconnexion</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  top: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: colors.inkSoft, paddingTop: 64, paddingBottom: 26, paddingHorizontal: 20 },
  av: { width: 64, height: 64, borderRadius: 20, borderWidth: 3, borderColor: 'rgba(255,255,255,0.15)', backgroundColor: '#1c474e' },
  name: { fontFamily: fonts.display, fontSize: 21, color: '#fff' },
  email: { fontFamily: fonts.body, fontSize: 12.5, color: '#9FB6B7', marginTop: 2 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 13, backgroundColor: '#fff', borderWidth: 1, borderColor: colors.line, borderRadius: 15, padding: 14, marginBottom: 9 },
  rowIc: { width: 38, height: 38, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  rowLabel: { flex: 1, fontFamily: fonts.bodySemi, fontSize: 14, color: colors.ink },
  langToggle: { flexDirection: 'row', backgroundColor: '#eef2f1', borderRadius: 10, padding: 3, gap: 3 },
  langBtn: { paddingHorizontal: 11, paddingVertical: 6, borderRadius: 8 },
  langBtnOn: { backgroundColor: '#fff' },
  langTxt: { fontFamily: fonts.bodyBold, fontSize: 12, color: colors.muted },
  langTxtOn: { color: colors.ink },
});
