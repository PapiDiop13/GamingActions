import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, fonts, shadow } from '../../theme';

const SLIDES = [
  { art: '📍', h: 'Les bons pros, autour de toi', p: 'Plombier, mécano, coiffeur, resto… vois qui est disponible tout près de chez toi, en temps réel.' },
  { art: '⚡', h: 'En live, maintenant', p: 'Les pros passent en ligne quand ils sont dispos. Tu les contactes, vous discutez, ils interviennent.' },
  { art: '⭐', h: 'Choisis en confiance', p: 'Prix moyen, notes et avis de vrais clients. Tu notes à la fin pour aider la communauté.' },
];

export default function OnboardingScreen({ navigation }) {
  const [i, setI] = useState(0);
  const next = () => (i < SLIDES.length - 1 ? setI(i + 1) : navigation.replace('Auth'));

  return (
    <View style={styles.root}>
      <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom']}>
        <TouchableOpacity style={styles.skip} onPress={() => navigation.replace('Auth')}>
          <Text style={styles.skipTxt}>Passer</Text>
        </TouchableOpacity>

        <View style={styles.stage}>
          <View style={styles.art}><Text style={{ fontSize: 74 }}>{SLIDES[i].art}</Text></View>
          <Text style={styles.h}>{SLIDES[i].h}</Text>
          <Text style={styles.p}>{SLIDES[i].p}</Text>
        </View>

        <View style={styles.dots}>
          {SLIDES.map((_, k) => (
            <View key={k} style={[styles.dot, k === i && styles.dotOn]} />
          ))}
        </View>

        <View style={styles.foot}>
          <TouchableOpacity style={styles.btn} onPress={next} activeOpacity={0.9}>
            <Text style={styles.btnTxt}>{i === SLIDES.length - 1 ? 'Commencer' : 'Suivant'}</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0E2A2F' },
  skip: { alignSelf: 'flex-end', padding: 18 },
  skipTxt: { fontFamily: fonts.bodySemi, fontSize: 13, color: '#7d9698' },
  stage: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 30 },
  art: { width: 172, height: 172, borderRadius: 86, alignItems: 'center', justifyContent: 'center', marginBottom: 30, backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)' },
  h: { fontFamily: fonts.display, fontSize: 27, color: '#fff', textAlign: 'center', marginBottom: 12 },
  p: { fontFamily: fonts.body, fontSize: 14.5, color: '#9FB6B7', textAlign: 'center', lineHeight: 23, maxWidth: 290 },
  dots: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginBottom: 24 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: 'rgba(255,255,255,0.2)' },
  dotOn: { width: 26, backgroundColor: colors.coral },
  foot: { paddingHorizontal: 26, paddingBottom: 16 },
  btn: { backgroundColor: colors.coral, borderRadius: 16, paddingVertical: 16, alignItems: 'center', ...shadow(14) },
  btnTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 15 },
});
