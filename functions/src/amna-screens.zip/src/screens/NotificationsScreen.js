import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { colors, fonts, shadow } from '../../theme';
import { notifications } from '../data/pros';

export default function NotificationsScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <View style={styles.head}>
        <TouchableOpacity style={styles.back} onPress={() => navigation.goBack()}>
          <Feather name="chevron-left" size={20} color={colors.ink} />
        </TouchableOpacity>
        <Text style={styles.title}>Notifications</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {notifications.map((n) => (
          <View key={n.id} style={[styles.notif, n.unread && styles.notifUnread]}>
            <View style={[styles.ic, { backgroundColor: n.tint }]}>
              <Text style={{ fontSize: 19 }}>{n.icon}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.txt}>{n.txt}</Text>
              <Text style={styles.time}>{n.time}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  head: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingTop: 6, paddingBottom: 12 },
  back: { width: 40, height: 40, borderRadius: 13, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', ...shadow(8) },
  title: { fontFamily: fonts.display, fontSize: 20, color: colors.ink },
  notif: { flexDirection: 'row', gap: 12, paddingHorizontal: 18, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: '#EEF2F1' },
  notifUnread: { backgroundColor: '#FFF8F6' },
  ic: { width: 42, height: 42, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  txt: { fontFamily: fonts.body, fontSize: 13.5, color: colors.ink, lineHeight: 19 },
  time: { fontFamily: fonts.bodySemi, fontSize: 11, color: colors.muted2, marginTop: 4 },
});
