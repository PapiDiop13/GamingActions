import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Animated } from 'react-native';
import { useRoute } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';
import { colors, fonts, shadow } from '../../theme';
import { getPro } from '../data/pros';

export default function CallScreen({ navigation }) {
  const route = useRoute();
  const p = getPro(route.params?.id) || getPro('modou');
  const [secs, setSecs] = useState(0);
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const t = setInterval(() => setSecs((s) => s + 1), 1000);
    const loop = Animated.loop(Animated.timing(pulse, { toValue: 1, duration: 2400, useNativeDriver: true }));
    loop.start();
    return () => { clearInterval(t); loop.stop(); };
  }, []);

  const mm = String(Math.floor(secs / 60)).padStart(2, '0');
  const ss = String(secs % 60).padStart(2, '0');

  return (
    <View style={styles.root}>
      <View style={styles.top}>
        <Text style={styles.label}>APPEL EN COURS</Text>
        <Text style={styles.name}>{p.name}</Text>
        <Text style={styles.timer}>{mm}:{ss}</Text>
      </View>

      <View style={styles.avWrap}>
        <Animated.View
          style={[
            styles.ring,
            { opacity: pulse.interpolate({ inputRange: [0, 1], outputRange: [0.6, 0] }), transform: [{ scale: pulse.interpolate({ inputRange: [0, 1], outputRange: [0.9, 1.4] }) }] },
          ]}
        />
        <Image source={{ uri: p.avatar }} style={styles.av} />
      </View>

      <View style={styles.controls}>
        <TouchableOpacity style={styles.cb}>
          <Feather name="mic-off" size={24} color="#fff" />
          <Text style={styles.cbL}>Muet</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.cb, styles.end]} onPress={() => navigation.goBack()}>
          <Feather name="phone-off" size={28} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.cb}>
          <Feather name="volume-2" size={24} color="#fff" />
          <Text style={styles.cbL}>HP</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0E2A2F', alignItems: 'center' },
  top: { paddingTop: 90, alignItems: 'center' },
  label: { fontFamily: fonts.bodySemi, fontSize: 13, color: '#8FB0B2', letterSpacing: 0.5 },
  name: { fontFamily: fonts.display, fontSize: 28, color: '#fff', marginTop: 8 },
  timer: { fontFamily: fonts.mono, fontSize: 15, color: colors.coral, marginTop: 8 },
  avWrap: { marginTop: 60, alignItems: 'center', justifyContent: 'center' },
  ring: { position: 'absolute', width: 150, height: 150, borderRadius: 75, borderWidth: 2, borderColor: 'rgba(255,86,48,0.3)' },
  av: { width: 120, height: 120, borderRadius: 60, borderWidth: 4, borderColor: 'rgba(255,255,255,0.18)', backgroundColor: '#1c474e' },
  controls: { flexDirection: 'row', alignItems: 'center', gap: 22, marginTop: 'auto', marginBottom: 70 },
  cb: { width: 64, height: 64, borderRadius: 32, backgroundColor: 'rgba(255,255,255,0.1)', alignItems: 'center', justifyContent: 'center', gap: 3 },
  cbL: { fontFamily: fonts.bodySemi, fontSize: 10, color: '#8FB0B2' },
  end: { width: 74, height: 74, borderRadius: 37, backgroundColor: '#FF3B30', ...shadow(16) },
});
