import React, { useRef, useState } from 'react';
import {
  View, Text, Image, TextInput, ScrollView, TouchableOpacity,
  KeyboardAvoidingView, Platform, StyleSheet,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRoute } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';
import { colors, fonts } from '../../theme';
import { getPro } from '../data/pros';

const SEED = [
  { me: false, t: 'Bonjour 👋 J\'ai une fuite sous l\'évier, vous pouvez passer ?', h: '14:02' },
  { me: true, t: 'Bonjour ! Oui je suis dispo. Vous êtes vers Sacré-Cœur ? J\'arrive dans 30 min.', h: '14:03' },
  { me: false, t: 'Parfait. C\'est combien environ ?', h: '14:03' },
  { me: true, t: 'Diagnostic gratuit, puis devis sur place. En général 5 000–8 000F.', h: '14:04' },
];

export default function ChatScreen({ navigation }) {
  const route = useRoute();
  const p = getPro(route.params?.id) || getPro('modou');
  const [msgs, setMsgs] = useState(SEED);
  const [text, setText] = useState('');
  const scrollRef = useRef(null);

  const send = () => {
    if (!text.trim()) return;
    setMsgs((m) => [...m, { me: true, t: text.trim(), h: 'maintenant' }]);
    setText('');
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 60);
  };

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <View style={styles.head}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Feather name="chevron-left" size={20} color={colors.ink} />
        </TouchableOpacity>
        <Image source={{ uri: p.avatar }} style={styles.headAv} />
        <View style={{ flex: 1 }}>
          <Text style={styles.headNm}>{p.name}</Text>
          <View style={styles.statusRow}>
            <View style={styles.statusDot} />
            <Text style={styles.statusTxt}>{p.live ? 'En live' : 'Hors ligne'} · {p.trade.split(' · ')[0]}</Text>
          </View>
        </View>
        <TouchableOpacity style={styles.callMini} onPress={() => navigation.navigate('Call', { id: p.id })}>
          <Feather name="phone" size={18} color="#fff" />
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={8}>
        <ScrollView ref={scrollRef} contentContainerStyle={styles.msgs} showsVerticalScrollIndicator={false} onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: false })}>
          <Text style={styles.day}>Aujourd'hui</Text>
          {msgs.map((m, i) => (
            <View key={i} style={[styles.bubble, m.me ? styles.bubbleMe : styles.bubbleThem]}>
              <Text style={[styles.bubbleTxt, m.me && { color: '#fff' }]}>{m.t}</Text>
              <Text style={[styles.bubbleH, m.me && { color: 'rgba(255,255,255,0.55)' }]}>{m.h}</Text>
            </View>
          ))}
        </ScrollView>

        <View style={styles.inputBar}>
          <TextInput
            style={styles.input}
            placeholder="Écris ton message…"
            placeholderTextColor={colors.muted2}
            value={text}
            onChangeText={setText}
            onSubmitEditing={send}
            returnKeyType="send"
          />
          <TouchableOpacity style={styles.sendBtn} onPress={send}>
            <Feather name="send" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  head: { flexDirection: 'row', alignItems: 'center', gap: 11, paddingHorizontal: 14, paddingVertical: 10, backgroundColor: colors.card, borderBottomWidth: 1, borderBottomColor: colors.line },
  backBtn: { width: 38, height: 38, borderRadius: 12, backgroundColor: '#eef2f1', alignItems: 'center', justifyContent: 'center' },
  headAv: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#cdd9d7' },
  headNm: { fontFamily: fonts.bodyBold, fontSize: 14.5, color: colors.ink },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 1 },
  statusDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.coral },
  statusTxt: { fontFamily: fonts.bodySemi, fontSize: 11.5, color: colors.coral },
  callMini: { width: 40, height: 40, borderRadius: 12, backgroundColor: colors.coral, alignItems: 'center', justifyContent: 'center' },
  msgs: { padding: 14, gap: 9 },
  day: { alignSelf: 'center', fontFamily: fonts.bodyMed, fontSize: 11, color: colors.muted, backgroundColor: 'rgba(0,0,0,0.05)', paddingHorizontal: 11, paddingVertical: 4, borderRadius: 9, marginBottom: 4, overflow: 'hidden' },
  bubble: { maxWidth: '78%', paddingHorizontal: 13, paddingVertical: 10, borderRadius: 16 },
  bubbleThem: { alignSelf: 'flex-start', backgroundColor: '#fff', borderWidth: 1, borderColor: colors.line, borderBottomLeftRadius: 5 },
  bubbleMe: { alignSelf: 'flex-end', backgroundColor: colors.ink, borderBottomRightRadius: 5 },
  bubbleTxt: { fontFamily: fonts.body, fontSize: 13.5, lineHeight: 19, color: colors.ink },
  bubbleH: { fontFamily: fonts.body, fontSize: 9.5, color: colors.muted2, marginTop: 4, textAlign: 'right' },
  inputBar: { flexDirection: 'row', gap: 9, padding: 12, backgroundColor: colors.card, borderTopWidth: 1, borderTopColor: colors.line },
  input: { flex: 1, borderWidth: 1, borderColor: colors.line, backgroundColor: '#F4F7F6', borderRadius: 14, paddingHorizontal: 15, paddingVertical: 12, fontFamily: fonts.body, fontSize: 14, color: colors.ink },
  sendBtn: { width: 46, height: 46, borderRadius: 14, backgroundColor: colors.coral, alignItems: 'center', justifyContent: 'center' },
});
