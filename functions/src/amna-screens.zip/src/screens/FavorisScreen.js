import React from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { colors, fonts } from '../../theme';
import { pros } from '../data/pros';

const FAV_IDS = ['modou', 'cheikh'];

export default function FavorisScreen({ navigation }) {
  const favs = pros.filter((p) => FAV_IDS.includes(p.id));

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <View style={styles.head}>
        <TouchableOpacity style={styles.back} onPress={() => navigation.goBack()}>
          <Feather name="chevron-left" size={20} color={colors.ink} />
        </TouchableOpacity>
        <Text style={styles.title}>Mes favoris</Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: 14, gap: 10 }} showsVerticalScrollIndicator={false}>
        {favs.map((p) => (
          <TouchableOpacity key={p.id} style={styles.card} activeOpacity={0.9} onPress={() => navigation.navigate('Profile', { id: p.id })}>
            <View>
              <Image source={{ uri: p.avatar }} style={styles.av} />
              {p.live && <View style={styles.lv} />}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.nm}>{p.name}</Text>
              <Text style={styles.sub}>{p.trade.split(' · ')[0]} · {p.live ? 'En live' : 'Hors ligne'}</Text>
              <View style={styles.meta}>
                <Text style={styles.star}>★ {p.rate}</Text>
                <Text style={styles.km}>{p.km.toString().replace('.', ',')} km</Text>
              </View>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={styles.price}>{p.price}</Text>
              <Text style={styles.priceL}>prix moyen</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  head: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingTop: 6, paddingBottom: 8 },
  back: { width: 40, height: 40, borderRadius: 13, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: fonts.display, fontSize: 20, color: colors.ink },
  card: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#fff', borderWidth: 1, borderColor: colors.line, borderRadius: 18, padding: 11 },
  av: { width: 54, height: 54, borderRadius: 15, backgroundColor: '#cdd9d7' },
  lv: { position: 'absolute', right: -3, bottom: -3, width: 15, height: 15, borderRadius: 8, backgroundColor: colors.coral, borderWidth: 2.5, borderColor: '#fff' },
  nm: { fontFamily: fonts.bodyBold, fontSize: 14.5, color: colors.ink },
  sub: { fontFamily: fonts.body, fontSize: 12, color: colors.muted, marginTop: 2 },
  meta: { flexDirection: 'row', gap: 10, marginTop: 6 },
  star: { fontFamily: fonts.bodyBold, fontSize: 12, color: colors.gold },
  km: { fontFamily: fonts.bodySemi, fontSize: 12, color: colors.muted },
  price: { fontFamily: fonts.mono, fontSize: 14, color: colors.ink },
  priceL: { fontFamily: fonts.bodySemi, fontSize: 9.5, color: colors.muted2 },
});
