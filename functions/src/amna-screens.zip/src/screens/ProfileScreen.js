import React from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { useRoute } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';
import { colors, fonts, shadow } from '../../theme';
import { getPro } from '../data/pros';

const GALLERY = [
  'https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?w=240&q=70',
  'https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?w=240&q=70',
  'https://images.unsplash.com/photo-1621905251918-48416bd8575a?w=240&q=70',
];
const REVIEWS = [
  { n: 'Awa S.', img: 12, s: 5, d: 'il y a 2 jours', t: 'Venu en 30 min pour une fuite. Travail nickel, prix correct.' },
  { n: 'Cheikh D.', img: 33, s: 5, d: 'il y a 5 jours', t: 'Très pro et ponctuel. Il a tout expliqué avant de commencer.' },
];

export default function ProfileScreen({ navigation }) {
  const route = useRoute();
  const p = getPro(route.params?.id) || getPro('modou');

  return (
    <View style={styles.root}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 120 }}>
        <View style={styles.cover}>
          <Image source={{ uri: p.cover }} style={StyleSheet.absoluteFill} />
          <View style={styles.coverGrad} />
          <TouchableOpacity style={[styles.circleBtn, { left: 16 }]} onPress={() => navigation.goBack()}>
            <Feather name="chevron-left" size={22} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.circleBtn, { right: 16 }]}>
            <Feather name="bookmark" size={19} color="#fff" />
          </TouchableOpacity>
        </View>

        <View style={styles.head}>
          <Image source={{ uri: p.avatar }} style={styles.av} />
          {p.live && (
            <View style={styles.liveBadge}>
              <View style={styles.liveDot} />
              <Text style={styles.liveTxt}>En live</Text>
            </View>
          )}
        </View>

        <View style={styles.body}>
          <View style={styles.nameRow}>
            <Text style={styles.name}>{p.name}</Text>
            {p.prem && <View style={styles.premb}><Text style={styles.prembTxt}>PRO+</Text></View>}
          </View>
          <Text style={styles.trade}>{p.trade}</Text>

          <View style={styles.stats}>
            <TouchableOpacity style={styles.stat} onPress={() => navigation.navigate('Reviews', { id: p.id })}>
              <Text style={[styles.statV, { color: colors.gold }]}>{p.rate}</Text>
              <Text style={styles.statL}>★ Note ({p.reviews} avis)</Text>
            </TouchableOpacity>
            <View style={styles.stat}>
              <Text style={styles.statV}>{p.km.toString().replace('.', ',')} km</Text>
              <Text style={styles.statL}>Distance</Text>
            </View>
            <View style={styles.stat}>
              <Text style={[styles.statV, { color: colors.coral }]}>{p.price}</Text>
              <Text style={styles.statL}>Prix moyen</Text>
            </View>
          </View>

          <Text style={styles.secHead}>À PROPOS</Text>
          <Text style={styles.about}>{p.about}</Text>

          <Text style={styles.secHead}>RÉALISATIONS</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 9 }}>
            {GALLERY.map((g) => <Image key={g} source={{ uri: g }} style={styles.galImg} />)}
          </ScrollView>

          <Text style={styles.secHead}>AVIS</Text>
          {REVIEWS.map((r) => (
            <View key={r.n} style={styles.review}>
              <View style={styles.reviewHead}>
                <Image source={{ uri: `https://i.pravatar.cc/80?img=${r.img}` }} style={styles.reviewAv} />
                <View>
                  <Text style={styles.reviewNm}>{r.n}</Text>
                  <Text style={styles.reviewD}>{r.d}</Text>
                </View>
                <Text style={styles.reviewStars}>{'★'.repeat(r.s)}</Text>
              </View>
              <Text style={styles.reviewTxt}>{r.t}</Text>
            </View>
          ))}
        </View>
      </ScrollView>

      <View style={styles.cta}>
        <TouchableOpacity style={[styles.ctaBtn, styles.ctaMsg]} onPress={() => navigation.navigate('Chat', { id: p.id })}>
          <Feather name="message-circle" size={18} color="#fff" />
          <Text style={styles.ctaTxt}>Message</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.ctaBtn, styles.ctaCall]} onPress={() => navigation.navigate('Call', { id: p.id })}>
          <Feather name="phone" size={18} color="#fff" />
          <Text style={styles.ctaTxt}>Appeler</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  cover: { height: 200 },
  coverGrad: { position: 'absolute', top: 0, left: 0, right: 0, height: 110, backgroundColor: 'rgba(14,42,47,0.3)' },
  circleBtn: { position: 'absolute', top: 52, width: 40, height: 40, borderRadius: 13, backgroundColor: 'rgba(0,0,0,0.35)', alignItems: 'center', justifyContent: 'center' },
  head: { paddingHorizontal: 18, marginTop: -44, flexDirection: 'row', alignItems: 'flex-end', gap: 13 },
  av: { width: 88, height: 88, borderRadius: 24, borderWidth: 4, borderColor: colors.bg, backgroundColor: '#cdd9d7', ...shadow(12) },
  liveBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: colors.coral, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10, marginBottom: 8 },
  liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#fff' },
  liveTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 11 },
  body: { padding: 18 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  name: { fontFamily: fonts.display, fontSize: 23, color: colors.ink },
  premb: { backgroundColor: colors.gold, paddingHorizontal: 7, paddingVertical: 3, borderRadius: 7 },
  prembTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 10 },
  trade: { fontFamily: fonts.bodyMed, fontSize: 13.5, color: colors.muted, marginTop: 2 },
  stats: { flexDirection: 'row', gap: 10, marginTop: 14 },
  stat: { flex: 1, backgroundColor: '#fff', borderWidth: 1, borderColor: colors.line, borderRadius: 16, padding: 12, alignItems: 'center' },
  statV: { fontFamily: fonts.display, fontSize: 18, color: colors.ink },
  statL: { fontFamily: fonts.bodySemi, fontSize: 10.5, color: colors.muted, marginTop: 2, textAlign: 'center' },
  secHead: { fontFamily: fonts.bodyBold, fontSize: 12, color: colors.muted, letterSpacing: 0.6, marginTop: 22, marginBottom: 9 },
  about: { fontFamily: fonts.body, fontSize: 14, lineHeight: 22, color: colors.inkSoft },
  galImg: { width: 108, height: 84, borderRadius: 14, backgroundColor: '#dde6e4' },
  review: { backgroundColor: '#fff', borderWidth: 1, borderColor: colors.line, borderRadius: 16, padding: 13, marginBottom: 9 },
  reviewHead: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  reviewAv: { width: 34, height: 34, borderRadius: 10, backgroundColor: '#cdd9d7' },
  reviewNm: { fontFamily: fonts.bodyBold, fontSize: 13, color: colors.ink },
  reviewD: { fontFamily: fonts.bodyMed, fontSize: 10.5, color: colors.muted2 },
  reviewStars: { marginLeft: 'auto', color: colors.gold, fontSize: 12 },
  reviewTxt: { fontFamily: fonts.body, fontSize: 13, lineHeight: 20, color: colors.inkSoft, marginTop: 8 },
  cta: { position: 'absolute', left: 0, right: 0, bottom: 0, flexDirection: 'row', gap: 10, padding: 16, paddingBottom: 28, backgroundColor: colors.bg },
  ctaBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 16, paddingVertical: 15 },
  ctaMsg: { backgroundColor: colors.ink },
  ctaCall: { backgroundColor: colors.coral, ...shadow(14) },
  ctaTxt: { color: '#fff', fontFamily: fonts.bodyBold, fontSize: 15 },
});
