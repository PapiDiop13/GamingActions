import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { colors, fonts } from '../../theme';

export default function Placeholder({ title, icon = 'layout', note }) {
  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.center}>
        <View style={styles.iconWrap}>
          <Feather name={icon} size={30} color={colors.coral} />
        </View>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.note}>{note || 'Écran à construire ensemble.'}</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30 },
  iconWrap: {
    width: 72, height: 72, borderRadius: 22, backgroundColor: '#FFF0EC',
    alignItems: 'center', justifyContent: 'center', marginBottom: 18,
  },
  title: { fontFamily: fonts.display, fontSize: 22, color: colors.ink },
  note: { fontFamily: fonts.bodyMed, fontSize: 13.5, color: colors.muted, marginTop: 8, textAlign: 'center', lineHeight: 20 },
});
