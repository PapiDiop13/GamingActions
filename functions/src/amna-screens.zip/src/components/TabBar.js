import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, fonts, shadow } from '../../theme';

const ICONS = {
  Accueil: 'home',
  Carte: 'map',
  Messages: 'message-circle',
  Profil: 'user',
};

export default function TabBar({ state, descriptors, navigation }) {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.bar, { paddingBottom: Math.max(insets.bottom, 8) }]}>
      {state.routes.map((route, index) => {
        const focused = state.index === index;
        const onPress = () => {
          const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
          if (!focused && !event.defaultPrevented) navigation.navigate(route.name);
        };

        // Bouton central "Pro"
        if (route.name === 'Pro') {
          return (
            <TouchableOpacity key={route.key} style={styles.center} onPress={onPress} activeOpacity={0.9}>
              <View style={styles.blob}>
                <Feather name="zap" size={26} color="#fff" />
              </View>
            </TouchableOpacity>
          );
        }

        return (
          <TouchableOpacity key={route.key} style={styles.item} onPress={onPress} activeOpacity={0.7}>
            <Feather name={ICONS[route.name]} size={23} color={focused ? colors.coral : colors.muted2} />
            <Text style={[styles.label, { color: focused ? colors.coral : colors.muted2 }]}>{route.name}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderTopWidth: 1,
    borderTopColor: colors.line,
    paddingTop: 8,
    alignItems: 'center',
  },
  item: { flex: 1, alignItems: 'center', gap: 3 },
  label: { fontFamily: fonts.bodySemi, fontSize: 10 },
  center: { flex: 1, alignItems: 'center' },
  blob: {
    width: 54, height: 54, borderRadius: 18, marginTop: -22,
    backgroundColor: colors.coral, alignItems: 'center', justifyContent: 'center',
    ...shadow(16),
  },
});
