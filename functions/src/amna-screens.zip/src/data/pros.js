// Données de démo. Abonnements masqués pour l'instant : tout le monde est en gratuit
// (prem = false partout). Pour réactiver les paliers plus tard, remettre prem: true.

export const categories = [
  { key: 'Plombier', emoji: '🔧', tint: '#E6F4F1' },
  { key: 'Mécano', emoji: '🚗', tint: '#FDEEE8' },
  { key: 'Coiffeur', emoji: '💈', tint: '#F1ECFB' },
  { key: 'Électricien', emoji: '⚡', tint: '#FCF4E2' },
  { key: 'Resto', emoji: '🍽️', tint: '#FDEDE9' },
  { key: 'Ménage', emoji: '🧹', tint: '#E9F4EC' },
  { key: 'Couture', emoji: '🧵', tint: '#FBEAF3' },
  { key: 'Froid/Clim', emoji: '❄️', tint: '#E7F1FB' },
  { key: 'Tout voir', emoji: '➕', tint: '#EEF2F1' },
];

export const pros = [
  {
    id: 'modou', name: 'Modou Faye', trade: 'Plomberie · Dépannage urgence · 24/7',
    rate: 4.9, reviews: 128, price: '7 500F', km: 1.2, walk: 15, drive: 5,
    prem: false, live: true, lat: 14.706, lng: -17.46,
    avatar: 'https://i.pravatar.cc/200?img=68',
    cover: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=70',
    about: "Plombier depuis 9 ans à Dakar. Fuites, chauffe-eau, installations, débouchage. J'interviens vite et proprement. Devis gratuit avant chaque intervention.",
  },
  {
    id: 'awa', name: 'Awa Diallo', trade: 'Plomberie · Sanitaire · Installation',
    rate: 4.7, reviews: 64, price: '6 000F', km: 0.9, walk: 11, drive: 4,
    prem: false, live: true, lat: 14.712, lng: -17.452,
    avatar: 'https://i.pravatar.cc/200?img=45',
    cover: 'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=600&q=70',
    about: 'Spécialiste sanitaire et robinetterie. Travail soigné, tarifs clairs. Disponible en semaine et le samedi.',
  },
  {
    id: 'cheikh', name: 'Cheikh Ndiaye', trade: 'Plomberie · Chauffe-eau · Dépannage',
    rate: 4.8, reviews: 91, price: '8 000F', km: 2.1, walk: 26, drive: 7,
    prem: false, live: true, lat: 14.70, lng: -17.448,
    avatar: 'https://i.pravatar.cc/200?img=53',
    cover: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=600&q=70',
    about: "15 ans d'expérience. Pose et réparation de chauffe-eau, détection de fuites, rénovation salle de bain.",
  },
  {
    id: 'ndeye', name: 'Ndeye Sarr', trade: 'Plomberie · Petites réparations',
    rate: 4.5, reviews: 37, price: '4 500F', km: 2.8, walk: 34, drive: 9,
    prem: false, live: false, lat: 14.715, lng: -17.47,
    avatar: 'https://i.pravatar.cc/200?img=20',
    cover: 'https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?w=600&q=70',
    about: 'Réparations rapides et abordables. Idéal pour les petits dépannages du quotidien.',
  },
  {
    id: 'ibou', name: 'Ibou Gueye', trade: 'Plomberie · Débouchage · Urgence',
    rate: 4.6, reviews: 52, price: '5 500F', km: 1.7, walk: 21, drive: 6,
    prem: false, live: true, lat: 14.708, lng: -17.455,
    avatar: 'https://i.pravatar.cc/200?img=14',
    cover: 'https://images.unsplash.com/photo-1635424709842-c7a7e0e6d9d3?w=600&q=70',
    about: 'Débouchage canalisations, WC, éviers. Intervention rapide jour et nuit.',
  },
];

export const getPro = (id) => pros.find((p) => p.id === id);

export const conversations = [
  { proId: 'modou', last: 'Diagnostic gratuit, puis devis sur place…', time: '14:04', unread: 0 },
  { proId: 'awa', last: 'Je peux passer demain matin 👍', time: '12:30', unread: 2 },
  { proId: 'cheikh', last: 'Merci pour la confiance ! À bientôt.', time: 'Hier', unread: 0 },
  { proId: 'ibou', last: "Vous : ok parfait, j'attends", time: 'Lun', unread: 0 },
];

export const requests = [
  { id: 'r1', name: 'Fatou Mbaye', img: 32, meta: '🔧 Fuite cuisine · 0,8 km', time: 'il y a 3 min', msg: "Bonjour, j'ai une fuite sous l'évier, vous êtes dispo maintenant ?" },
  { id: 'r2', name: 'Ousmane Ba', img: 15, meta: '🔧 Chauffe-eau · 1,5 km', time: 'il y a 12 min', msg: "Mon chauffe-eau ne marche plus, c'est possible aujourd'hui ?" },
];

export const notifications = [
  { id: 'n1', icon: '💬', tint: '#FFF0EC', unread: true, txt: "Modou Faye t'a répondu : « J'arrive dans 30 min »", time: 'il y a 2 min' },
  { id: 'n2', icon: '⚡', tint: '#E6F4F1', unread: true, txt: 'Cheikh Ndiaye vient de passer en live près de toi', time: 'il y a 18 min' },
  { id: 'n3', icon: '⭐', tint: '#FCF4E2', unread: false, txt: 'Pense à noter Awa Diallo après votre intervention', time: 'il y a 1 j' },
  { id: 'n4', icon: '🎁', tint: '#F1ECFB', unread: false, txt: 'Bienvenue sur Amna ! Découvre les pros autour de toi', time: 'il y a 3 j' },
];

export const reviewsList = [
  { n: 'Awa S.', img: 12, s: 5, d: 'il y a 2 jours', t: 'Venu en 30 min pour une fuite. Travail nickel, prix correct. Je recommande à 100%.' },
  { n: 'Cheikh D.', img: 33, s: 5, d: 'il y a 5 jours', t: 'Très pro et ponctuel. Il a tout expliqué avant de commencer.' },
  { n: 'Fatou M.', img: 32, s: 5, d: 'il y a 1 sem.', t: 'Super travail sur mon chauffe-eau. Je le rappellerai sans hésiter.' },
  { n: 'Ousmane B.', img: 15, s: 4, d: 'il y a 2 sem.', t: 'Bon travail, juste un petit retard mais il a prévenu.' },
  { n: 'Ndeye S.', img: 20, s: 5, d: 'il y a 3 sem.', t: 'Rapide, propre et sympa. Merci !' },
];
